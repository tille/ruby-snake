

dystopia prop pack        

by      

soenke c. "warby" seidel







this prop pack is free for any kind of use including commercial.
i am asking for nothing but to be credited where ever these props find use.
as you can tell by the name this prop pack was made for the mod dystopia but any
sci-fi/cyberpunk themed hl2 mod/map should feel free to use em.
if you have the tools and ambition to convert the props from the
half life *.mdl and *.vtf format to the native format of another game/3d engine go for it.
don't contact me to maintain these props or textures in anyway please.
also don't contact me requesting more props or props of another theme please.
advertising this prop pack on your favorite game related board is highly encouraged :)
estimated build time 1.5 month

Or use this content under the conditions of the CreativeCommons Attribution 3.0 license:
http://creativecommons.org/licenses/by/3.0/





greetings warby



visit
www.warby.de